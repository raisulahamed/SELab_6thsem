import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_URL = "http://localhost:5000/items";

function App() {
  const [items, setItems] = useState([]);
  const [formData, setFormData] = useState({ name: '' });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    axios.get(API_URL).then(res => setItems(res.data));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editId) {
      axios.put(`${API_URL}/${editId}`, formData).then(res => {
        setItems(items.map(item => (item.id === editId ? res.data : item)));
        setFormData({ name: '' });
        setEditId(null);
      });
    } else {
      axios.post(API_URL, formData).then(res => {
        setItems([...items, res.data]);
        setFormData({ name: '' });
      });
    }
  };

  const handleEdit = (item) => {
    setFormData({ name: item.name });
    setEditId(item.id);
  };

  const handleDelete = (id) => {
    axios.delete(`${API_URL}/${id}`).then(() =>
      setItems(items.filter(item => item.id !== id))
    );
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Item Manager</h1>
      <form onSubmit={handleSubmit}>
        <input
          value={formData.name}
          onChange={(e) => setFormData({ name: e.target.value })}
          placeholder="Enter item name"
          required
        />
        <button type="submit">{editId ? 'Update' : 'Add'}</button>
      </form>

      <ul>
        {items.map(item => (
          <li key={item.id}>
            {item.name} &nbsp;
            <button onClick={() => handleEdit(item)}>Edit</button>
            <button onClick={() => handleDelete(item.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;

function Card({ name }) {
  return (
    <div style={{ border: '1px solid #ccc', margin: '10px', padding: '10px' }}>
      <h3>{name}</h3>
    </div>
  );
}
export default Card;

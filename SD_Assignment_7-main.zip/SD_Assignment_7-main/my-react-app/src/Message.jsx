function Message({ content }) {
  return <p>{content}</p>;
}
export default Message;
